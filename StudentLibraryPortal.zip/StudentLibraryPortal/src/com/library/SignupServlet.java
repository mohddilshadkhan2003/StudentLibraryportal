package com.library;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;

@WebServlet("/api/signup")
public class SignupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json");

        String fullName   = trim(req.getParameter("fullName"));
        String rollNumber = trim(req.getParameter("rollNumber"));
        String email      = trim(req.getParameter("email"));
        String password   = req.getParameter("password");

        if (fullName.isEmpty() || rollNumber.isEmpty() || email.isEmpty() ||
                password == null || password.length() < 6) {
            writeJson(resp, false, "Please fill every field. Password must be at least 6 characters.");
            return;
        }

        String sql = "INSERT INTO users (full_name, roll_number, email, password_hash) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, fullName);
            ps.setString(2, rollNumber);
            ps.setString(3, email);
            ps.setString(4, PasswordUtil.hash(password));
            ps.executeUpdate();

            writeJson(resp, true, "Account created. You can log in now.");

        } catch (SQLIntegrityConstraintViolationException dup) {
            writeJson(resp, false, "That roll number or email is already registered.");
        } catch (Exception e) {
            e.printStackTrace();
            writeJson(resp, false, "Server error. Please try again.");
        }
    }

    private String trim(String s) {
        return s == null ? "" : s.trim();
    }

    private void writeJson(HttpServletResponse resp, boolean success, String message) throws IOException {
        resp.getWriter().write("{\"success\": " + success + ", \"message\": \"" + escape(message) + "\"}");
    }

    private String escape(String s) {
        return s.replace("\"", "\\\"");
    }
}

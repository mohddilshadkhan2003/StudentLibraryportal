package com.library;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/api/borrow")
public class BorrowServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json");
        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            resp.getWriter().write("{\"success\": false, \"message\": \"Please log in first.\"}");
            return;
        }

        int userId = (int) session.getAttribute("userId");
        int bookId;
        try {
            bookId = Integer.parseInt(req.getParameter("bookId"));
        } catch (Exception e) {
            resp.getWriter().write("{\"success\": false, \"message\": \"Invalid book.\"}");
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            conn.setAutoCommit(false);

            // Lock the row and check availability
            PreparedStatement check = conn.prepareStatement(
                "SELECT available_copies FROM books WHERE book_id = ? FOR UPDATE");
            check.setInt(1, bookId);
            ResultSet rs = check.executeQuery();

            if (!rs.next() || rs.getInt("available_copies") <= 0) {
                conn.rollback();
                resp.getWriter().write("{\"success\": false, \"message\": \"No copies available right now.\"}");
                return;
            }

            PreparedStatement update = conn.prepareStatement(
                "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?");
            update.setInt(1, bookId);
            update.executeUpdate();

            PreparedStatement insert = conn.prepareStatement(
                "INSERT INTO borrow_records (user_id, book_id, due_date) VALUES (?, ?, DATE_ADD(CURDATE(), INTERVAL 14 DAY))");
            insert.setInt(1, userId);
            insert.setInt(2, bookId);
            insert.executeUpdate();

            conn.commit();
            resp.getWriter().write("{\"success\": true, \"message\": \"Checked out for 14 days.\"}");

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("{\"success\": false, \"message\": \"Server error. Please try again.\"}");
        }
    }
}

package com.library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Central place that opens a JDBC connection to MySQL.
 * Edit DB_URL / DB_USER / DB_PASSWORD to match your local MySQL setup.
 */
public class DBUtil {

    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/library_portal?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "your_mysql_password"; // <-- change this

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(
                "MySQL JDBC driver not found on classpath. " +
                "Add mysql-connector-j-x.x.x.jar to WEB-INF/lib.", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}

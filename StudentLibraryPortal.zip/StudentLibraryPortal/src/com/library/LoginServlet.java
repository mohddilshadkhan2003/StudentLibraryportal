package com.library;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json");

        String rollNumber = req.getParameter("rollNumber");
        String password   = req.getParameter("password");

        String sql = "SELECT user_id, full_name, roll_number, password_hash FROM users WHERE roll_number = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, rollNumber);
            ResultSet rs = ps.executeQuery();

            if (rs.next() && PasswordUtil.verify(password, rs.getString("password_hash"))) {
                HttpSession session = req.getSession(true);
                session.setAttribute("userId", rs.getInt("user_id"));
                session.setAttribute("fullName", rs.getString("full_name"));
                session.setAttribute("rollNumber", rs.getString("roll_number"));

                resp.getWriter().write(
                    "{\"success\": true, \"fullName\": \"" + escape(rs.getString("full_name")) + "\"}");
            } else {
                resp.getWriter().write(
                    "{\"success\": false, \"message\": \"Invalid roll number or password.\"}");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("{\"success\": false, \"message\": \"Server error. Please try again.\"}");
        }
    }

    private String escape(String s) {
        return s.replace("\"", "\\\"");
    }
}

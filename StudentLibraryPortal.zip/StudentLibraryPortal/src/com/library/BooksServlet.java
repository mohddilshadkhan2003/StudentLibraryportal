package com.library;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/api/books")
public class BooksServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json");
        String q = req.getParameter("q");

        String sql = "SELECT book_id, title, author, category, available_copies, total_copies " +
                     "FROM books WHERE title LIKE ? OR author LIKE ? OR category LIKE ? ORDER BY title";

        StringBuilder json = new StringBuilder("[");

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String like = "%" + (q == null ? "" : q) + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);

            ResultSet rs = ps.executeQuery();
            boolean first = true;
            while (rs.next()) {
                if (!first) json.append(",");
                first = false;
                json.append("{")
                    .append("\"bookId\":").append(rs.getInt("book_id")).append(",")
                    .append("\"title\":\"").append(escape(rs.getString("title"))).append("\",")
                    .append("\"author\":\"").append(escape(rs.getString("author"))).append("\",")
                    .append("\"category\":\"").append(escape(rs.getString("category"))).append("\",")
                    .append("\"available\":").append(rs.getInt("available_copies")).append(",")
                    .append("\"total\":").append(rs.getInt("total_copies"))
                    .append("}");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        json.append("]");
        resp.getWriter().write(json.toString());
    }

    private String escape(String s) {
        return s == null ? "" : s.replace("\"", "\\\"");
    }
}

const grid = document.getElementById('catalogGrid');
const searchInput = document.getElementById('searchInput');
const welcomeName = document.getElementById('welcomeName');

async function checkSession() {
    const res = await fetch('api/session', { credentials: 'same-origin' });
    const data = await res.json();
    if (!data.loggedIn) {
        window.location.href = 'login.html';
        return;
    }
    welcomeName.textContent = data.fullName;
}

async function loadBooks(query = '') {
    grid.innerHTML = '<div class="empty-state">Loading catalog…</div>';
    const res = await fetch('api/books?q=' + encodeURIComponent(query), { credentials: 'same-origin' });
    const books = await res.json();

    if (!books.length) {
        grid.innerHTML = '<div class="empty-state">No books match that search.</div>';
        return;
    }

    grid.innerHTML = '';
    books.forEach(book => {
        const available = book.available > 0;
        const card = document.createElement('div');
        card.className = 'book-card';
        card.innerHTML = `
            <span class="cat">${escapeHtml(book.category || 'General')}</span>
            <h3>${escapeHtml(book.title)}</h3>
            <div class="author">${escapeHtml(book.author)}</div>
            <div class="foot">
                <span class="avail-tag ${available ? 'yes' : 'no'}">
                    ${available ? book.available + ' available' : 'checked out'}
                </span>
                <button class="borrow-btn" data-id="${book.bookId}" ${available ? '' : 'disabled'}>
                    ${available ? 'Borrow' : 'Unavailable'}
                </button>
            </div>
        `;
        grid.appendChild(card);
    });

    grid.querySelectorAll('.borrow-btn').forEach(btn => {
        btn.addEventListener('click', () => borrowBook(btn));
    });
}

async function borrowBook(btn) {
    btn.disabled = true;
    btn.textContent = 'Checking out…';
    try {
        const body = new URLSearchParams({ bookId: btn.dataset.id });
        const res = await fetch('api/borrow', { method: 'POST', body, credentials: 'same-origin' });
        const result = await res.json();
        if (result.success) {
            loadBooks(searchInput.value.trim());
        } else {
            alert(result.message);
            btn.disabled = false;
            btn.textContent = 'Borrow';
        }
    } catch (err) {
        alert('Could not reach the server.');
        btn.disabled = false;
        btn.textContent = 'Borrow';
    }
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

let debounceTimer;
searchInput.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => loadBooks(searchInput.value.trim()), 250);
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
    await fetch('api/logout', { method: 'POST', credentials: 'same-origin' });
    window.location.href = 'login.html';
});

checkSession().then(() => loadBooks());

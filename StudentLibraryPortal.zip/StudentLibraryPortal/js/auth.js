function showMsg(el, text, type) {
    el.textContent = text;
    el.className = 'msg show ' + type;
}

function postForm(url, formEl) {
    const data = new URLSearchParams(new FormData(formEl));
    return fetch(url, {
        method: 'POST',
        body: data,
        credentials: 'same-origin'
    }).then(r => r.json());
}

// ---------- Signup page ----------
const signupForm = document.getElementById('signupForm');
if (signupForm) {
    const msg = document.getElementById('signupMsg');
    signupForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = signupForm.querySelector('button');
        btn.disabled = true;
        try {
            const result = await postForm('api/signup', signupForm);
            showMsg(msg, result.message, result.success ? 'success' : 'error');
            if (result.success) {
                setTimeout(() => { window.location.href = 'login.html'; }, 1000);
            }
        } catch (err) {
            showMsg(msg, 'Could not reach the server. Is Tomcat running?', 'error');
        } finally {
            btn.disabled = false;
        }
    });
}

// ---------- Login page ----------
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    const msg = document.getElementById('loginMsg');
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = loginForm.querySelector('button');
        btn.disabled = true;
        try {
            const result = await postForm('api/login', loginForm);
            if (result.success) {
                window.location.href = 'dashboard.html';
            } else {
                showMsg(msg, result.message, 'error');
            }
        } catch (err) {
            showMsg(msg, 'Could not reach the server. Is Tomcat running?', 'error');
        } finally {
            btn.disabled = false;
        }
    });
}

-- ============================================================
-- Student Library Portal — Database Schema
-- Run this whole file in MySQL Workbench / mysql CLI once.
-- ============================================================

CREATE DATABASE IF NOT EXISTS library_portal;
USE library_portal;

-- ---------- Users ----------
CREATE TABLE IF NOT EXISTS users (
    user_id        INT AUTO_INCREMENT PRIMARY KEY,
    full_name      VARCHAR(100)  NOT NULL,
    roll_number    VARCHAR(30)   NOT NULL UNIQUE,
    email          VARCHAR(150)  NOT NULL UNIQUE,
    password_hash  VARCHAR(255)  NOT NULL,
    created_at     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Books ----------
CREATE TABLE IF NOT EXISTS books (
    book_id        INT AUTO_INCREMENT PRIMARY KEY,
    title          VARCHAR(200)  NOT NULL,
    author         VARCHAR(150)  NOT NULL,
    isbn           VARCHAR(30)   UNIQUE,
    category       VARCHAR(80),
    total_copies   INT           NOT NULL DEFAULT 1,
    available_copies INT         NOT NULL DEFAULT 1
);

-- ---------- Borrow records ----------
CREATE TABLE IF NOT EXISTS borrow_records (
    record_id      INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT NOT NULL,
    book_id        INT NOT NULL,
    borrowed_on    DATE NOT NULL DEFAULT (CURRENT_DATE),
    due_date       DATE NOT NULL,
    returned_on    DATE NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE
);

-- ---------- Sample catalog data so the dashboard isn't empty ----------
INSERT INTO books (title, author, isbn, category, total_copies, available_copies) VALUES
('Clean Code',                'Robert C. Martin',      '9780132350884', 'Computer Science', 4, 4),
('Introduction to Algorithms', 'Cormen, Leiserson et al.', '9780262046305', 'Computer Science', 3, 3),
('A Brief History of Time',   'Stephen Hawking',        '9780553380163', 'Physics',          2, 2),
('The Great Gatsby',          'F. Scott Fitzgerald',    '9780743273565', 'Literature',       5, 5),
('Sapiens',                   'Yuval Noah Harari',      '9780062316097', 'History',          3, 3),
('Design Patterns',           'Gamma, Helm, Johnson, Vlissides', '9780201633610', 'Computer Science', 2, 2);
